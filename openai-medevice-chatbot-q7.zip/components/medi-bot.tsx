export function MediBot() {
  return (
    <img className="logo" src="/medi_bot.png" alt="medibot icon" style={{ height: "20px", width: "20px" }} />
  )
}
