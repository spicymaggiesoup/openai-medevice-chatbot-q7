export function MediLogo() {
  return (
    <img className="logo" src="/logo_img.png" alt="mediBot logo" style={{ height: "35px" }} />
  )
}
