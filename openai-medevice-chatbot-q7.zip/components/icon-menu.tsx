import { Menu } from 'react-feather';

export function IconMenu() {
  return (
    <Menu />
  )
}