# Medical chatbot UI
https://v0-medical-chatbot-ui-xi.vercel.app/
